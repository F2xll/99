# Client Desktop GLPI

Client para abertura de chamados no GLPI via desktop.
