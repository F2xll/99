from PySide6.QtWidgets import QWidget
from interface.main import Ui_Main

class View(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

    def mensagem(self, lb, texto: str, status: bool, tipo: str) -> None:
        """tipo = [error, success]"""
        lb.setText(texto)
        tipos = {
            "success": "QLabel{color:white;background-color:rgb(87, 227, 137);border-radius: 5px;margin: 0px 40px;padding: 10px;}",
            "error": "QLabel{color:white;background-color:rgb(237, 51, 59);border-radius: 5px;margin: 0px 40px;padding: 10px;}",
        }
        lb.setStyleSheet(tipos[tipo])
        if status == True:
            lb.setMaximumHeight(50)
        else:
            lb.setMaximumHeight(0)

