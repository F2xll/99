from base_class.Controller import Controller
from PySide6.QtWidgets import QFileDialog


class AbrirChamadoController(Controller):

    def __init__(self, view, model, msg) -> None:
        super().__init__(view, model, msg)

        self._view.btn_adicionar.clicked.connect(lambda : self.criar_ticket())
        self._view.btn_anexo.clicked.connect(lambda : self.adicionar_anexo())

    def limpar(self):
        self._view.limpar(self._msg, self._model.all_urgencia, self._model.all_categoria())
        self._model.limpar_anexos()

    def adicionar_anexo(self):
        file = QFileDialog.getOpenFileName()[0]
        if file in self._model.get_anexos:
            self._view.mensagem(self._msg, 'Anexo já adicionado.', True, 'error')
        elif file != "":
            self._view.mensagem(self._msg, '', False, 'error')
            self._anexos = self._view.preencher_anexos(self._model.adicionar_anexo(file))

    def preencher_campos(self):
        self._view.preencher_cb(self._view.cb_urgencia, self._model.all_urgencia)

    def criar_ticket(self):

        if self._view.status is False:
            self._view.mensagem(self._msg, 'Preencha os campos corretamente!', True, 'error')
            return

        dados = self._view.get_dados

        for j, i in self._model.all_urgencia.items():
            if i == dados['urgency']:
                dados['urgency'] = j

        cat = self._model.all_categoria()

        for item in cat:
            for key, value in item.items():
                if value == dados['category']:
                    dados['category'] = key



        ticket = {
            "name": dados['name'],
            "content": dados['content'],
            "priority": "3",
            "itilcategories_id": f"{dados['category']}",
            "urgency": f"{dados['urgency']}",
            "impact": "3",
            "type": "2",
            "status": "1",
        }

        ticket = self._model.abrir_chamado(ticket)

        try:
            self._model.adicionar_item(ticket["id"])
        except:
            pass

        if len(self._model.get_anexos) != 0:
            self._model.adicionar_anexos(ticket["id"])

        self._view.limpar(self._msg, self._model.all_urgencia, self._model.all_categoria())
        self._model.limpar_anexos()
        self._view.mensagem(self._msg, 'Chamado Aberto com Sucesso!', True, 'success')
