from base_class.Controller import Controller


class DownloadsController(Controller):

    def __init__(self, view, model, msg) -> None:
        super().__init__(view, model, msg)
