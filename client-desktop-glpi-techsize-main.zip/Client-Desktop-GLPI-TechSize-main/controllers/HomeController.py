from base_class.Controller import Controller
from views.TokensView import TokensView
from models.TokensModel import TokensModel
from generics import carregar_json
import os


from controllers.TokensController import TokensController

#Views
from views.ChamadoView import ChamadosView
from views.AbrirChamadoView import AbrirChamadoView
from views.DownloadsView import DownloadsView

#Models
from models.AbrirChamadoModel import AbrirChamadoModel
from models.ChamadoModel import ChamadoModel
from models.DownloadsModel import DownloadsModel

#Controllers
from controllers.ChamadosController import ChamadosController
from controllers.AbrirChamadoController import AbrirChamadoController
from controllers.DownloadsController import DownloadsController


class HomeController(Controller):

    def __init__(self, view, model, msg=None) -> None:
        super().__init__(view, model, msg=None)

        if self.verificar_tokens() is True:
            self.showMaximized()
            self.iniciar_sessao()
            self.definir_user()
            self.definir_maquina()
        else:
            self._controllerToken.show()

        self._telas = {
            1: ChamadosController(ChamadosView(), ChamadoModel(self._model.api), self._view.lb_msg),
            2: AbrirChamadoController(AbrirChamadoView(), AbrirChamadoModel(self._model.api), self._view.lb_msg),
        }
        self.definir_telas()

        self._view.btn_chamados.clicked.connect(lambda: self.navegar(1, 'Chamados'))
        self._view.btn_abrirChamado.clicked.connect(lambda: self.navegar(2, 'Abrir Chamado'))

    def navegar(self, index, msg):
        self._telas[2].limpar()
        self._telas[1].home()
        self._view.navegar(index, msg)

    def verificar_tokens(self) -> bool:
        tokens = carregar_json.read_json()
        self._controllerToken = TokensController(TokensView(tokens), TokensModel(tokens['url'], tokens), self)
        if tokens['user_Token'] == '' or tokens['app_Token'] == '':
            self._controllerToken.show()
            return False
        else:
            if self._controllerToken.testar_tokens(tokens) is True:
                self._tokenAPI = tokens['app_Token']
                self._tokenUSER = tokens['user_Token']
                self._url = tokens['url']
                return True
            else:
                return False

    def iniciar_sessao(self):
        self._model.iniciar_sessao(self._tokenAPI, self._tokenUSER, self._url)

    def definir_telas(self):
        window = self._view.stackedWidget

        for index, tela in self._telas.items():
            window.insertWidget(index, tela._view)
        window.setCurrentIndex(0)

    def definir_maquina(self):
        self._view.nome_maquina(self._model.get_maquina)

    def definir_user(self):
        profiles = self._model.api.get_profiles()
        for i in profiles.keys():
            profile = profiles[i]
            break
        try:
            for i in profile['entities'].values():
                entidade = i
        except:
            for i in profile['entities']:
                entidade = i
        self._view.definir_user(self._model.api.user(), self._model.api.full_name(), entidade['name'])
