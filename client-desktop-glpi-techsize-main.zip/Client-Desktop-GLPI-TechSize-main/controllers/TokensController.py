import sys
from generics import carregar_json
from base_class.Controller import Controller
from views.TokensView import TokensView
from models.TokensModel import TokensModel
from generics.carregar_json import salvar_json


class TokensController(Controller):

    def __init__(self, view: TokensView, model: TokensModel, home,  msg=None) -> None:
        super().__init__(view, model, msg=None)
        self._home = home
        self._view.btn_cadastrar.clicked.connect(self.validar_tokens)

    def validar_tokens(self):
        self._model.set_tokens(self._view.salvar())
        if self._model.validar_tokens().status_code != 200:
            self._view.msg_error('Erro ao validar Tokens', True)
        else:
            salvar_json(dados=self._model.tokens)
            self._view.close()

            tokens = carregar_json.read_json()
            self._home._tokenAPI = tokens['app_Token']
            self._home._tokenUSER = tokens['user_Token']
            self._home._url = tokens['url']
            self._home.showMaximized()
            self._home.iniciar_sessao()
            self._home.definir_user()
            self._home.definir_maquina()


    def testar_tokens(self, tokens: dict):
        self._model.set_tokens(tokens)
        status = self._model.validar_tokens()
        if status.status_code != 200:
            return False
        else:
            return True

