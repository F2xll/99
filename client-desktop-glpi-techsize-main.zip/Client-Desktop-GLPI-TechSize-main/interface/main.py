# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'pJPFXs.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QPushButton,
    QSizePolicy, QSpacerItem, QStackedWidget, QVBoxLayout,
    QWidget)

class Ui_Main(object):
    def setupUi(self, Main):
        if not Main.objectName():
            Main.setObjectName(u"Main")
        Main.resize(1024, 562)
        Main.setStyleSheet(u"background-color: rgb(234, 237, 241);\n"
"font-family: \"Segoe UI\";")
        self.horizontalLayout = QHBoxLayout(Main)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.side_bar = QWidget(Main)
        self.side_bar.setObjectName(u"side_bar")
        self.side_bar.setMinimumSize(QSize(150, 0))
        self.side_bar.setMaximumSize(QSize(150, 16777215))
        self.side_bar.setStyleSheet(u"background-color: rgb(43, 62, 99);")
        self.verticalLayout_2 = QVBoxLayout(self.side_bar)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.toggle = QPushButton(self.side_bar)
        self.toggle.setObjectName(u"toggle")
        self.toggle.setMinimumSize(QSize(0, 100))
        self.toggle.setMaximumSize(QSize(16777215, 100))
        self.toggle.setStyleSheet(u"QPushButton {\n"
"	background: none;\n"
"	border: none;\n"
"\n"
"	padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	padding: 2px;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	padding: 3px;\n"
"}")

        self.verticalLayout_2.addWidget(self.toggle)

        self.nav_bar = QWidget(self.side_bar)
        self.nav_bar.setObjectName(u"nav_bar")
        self.nav_bar.setStyleSheet(u"QPushButton {\n"
"	background: none;\n"
"	border: none;\n"
"	padding: 4px;\n"
"	color: white;\n"
"	padding-left: 20px;\n"
"	text-align: left;\n"
"	font-size: 12px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	padding: 2px;\n"
"	background: rgb(28, 41, 69);\n"
"	border-left: 2px solid #E6A95F;\n"
"	color: #E6A95F;\n"
"\n"
"	padding-left: 20px;\n"
"	text-align: left;\n"
"	font-size: 12px;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background: rgb(39, 51, 76);\n"
"	padding-left: 20px;\n"
"	text-align: left;\n"
"	font-size: 12px;\n"
"}")
        self.verticalLayout_3 = QVBoxLayout(self.nav_bar)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.btn_chamados = QPushButton(self.nav_bar)
        self.btn_chamados.setObjectName(u"btn_chamados")
        self.btn_chamados.setMinimumSize(QSize(0, 50))
        self.btn_chamados.setMaximumSize(QSize(16777215, 50))
        font = QFont()
        font.setFamilies([u"Segoe UI"])
        font.setBold(True)
        font.setItalic(False)
        self.btn_chamados.setFont(font)
        self.btn_chamados.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_chamados.setStyleSheet(u"")

        self.verticalLayout_3.addWidget(self.btn_chamados)

        self.btn_abrirChamado = QPushButton(self.nav_bar)
        self.btn_abrirChamado.setObjectName(u"btn_abrirChamado")
        self.btn_abrirChamado.setMinimumSize(QSize(0, 50))
        self.btn_abrirChamado.setMaximumSize(QSize(16777215, 50))
        font1 = QFont()
        font1.setFamilies([u"Segoe UI"])
        font1.setBold(True)
        self.btn_abrirChamado.setFont(font1)
        self.btn_abrirChamado.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_abrirChamado.setStyleSheet(u"")

        self.verticalLayout_3.addWidget(self.btn_abrirChamado)

        self.lb_titulo_7 = QLabel(self.nav_bar)
        self.lb_titulo_7.setObjectName(u"lb_titulo_7")
        self.lb_titulo_7.setMinimumSize(QSize(0, 50))
        self.lb_titulo_7.setMaximumSize(QSize(16777215, 50))
        font2 = QFont()
        font2.setFamilies([u"Segoe UI"])
        font2.setBold(True)
        font2.setItalic(False)
        font2.setUnderline(False)
        font2.setStrikeOut(False)
        font2.setKerning(True)
        self.lb_titulo_7.setFont(font2)
        self.lb_titulo_7.setCursor(QCursor(Qt.PointingHandCursor))
        self.lb_titulo_7.setStyleSheet(u"QLabel {\n"
"	background: none;\n"
"	border: none;\n"
"	padding: 4px;\n"
"	color: white;\n"
"	padding-left: 20px;\n"
"	text-align: left;\n"
"	font-size: 12px;\n"
"}\n"
"\n"
"QLabel:hover {\n"
"	padding: 2px;\n"
"	background: rgb(28, 41, 69);\n"
"	border-left: 2px solid #E6A95F;\n"
"	color: #E6A95F;\n"
"\n"
"	padding-left: 20px;\n"
"	text-align: left;\n"
"	font-size: 12px;\n"
"}\n"
"")
        self.lb_titulo_7.setOpenExternalLinks(True)
        self.lb_titulo_7.setTextInteractionFlags(Qt.LinksAccessibleByMouse)

        self.verticalLayout_3.addWidget(self.lb_titulo_7)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer)

        self.lb_titulo_5 = QLabel(self.nav_bar)
        self.lb_titulo_5.setObjectName(u"lb_titulo_5")
        self.lb_titulo_5.setMinimumSize(QSize(50, 0))
        font3 = QFont()
        font3.setFamilies([u"Segoe UI"])
        font3.setPointSize(14)
        font3.setBold(True)
        self.lb_titulo_5.setFont(font3)
        self.lb_titulo_5.setStyleSheet(u"QLabel {\n"
"	color: rgb(0, 193, 255)\n"
"}")
        self.lb_titulo_5.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.lb_titulo_5)

        self.lb_titulo_4 = QLabel(self.nav_bar)
        self.lb_titulo_4.setObjectName(u"lb_titulo_4")
        self.lb_titulo_4.setMinimumSize(QSize(50, 0))
        font4 = QFont()
        font4.setFamilies([u"Segoe UI"])
        font4.setPointSize(25)
        font4.setBold(False)
        self.lb_titulo_4.setFont(font4)
        self.lb_titulo_4.setStyleSheet(u"QLabel {\n"
"	color: rgb(255, 255, 255)\n"
"}")
        self.lb_titulo_4.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.lb_titulo_4)

        self.lb_titulo_6 = QLabel(self.nav_bar)
        self.lb_titulo_6.setObjectName(u"lb_titulo_6")
        self.lb_titulo_6.setMinimumSize(QSize(50, 0))
        self.lb_titulo_6.setFont(font4)
        self.lb_titulo_6.setStyleSheet(u"QLabel {\n"
"	color: rgb(255, 255, 255)\n"
"}")
        self.lb_titulo_6.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.lb_titulo_6)


        self.verticalLayout_2.addWidget(self.nav_bar)


        self.horizontalLayout.addWidget(self.side_bar)

        self.content = QWidget(Main)
        self.content.setObjectName(u"content")
        self.verticalLayout = QVBoxLayout(self.content)
        self.verticalLayout.setSpacing(6)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.top_bar = QWidget(self.content)
        self.top_bar.setObjectName(u"top_bar")
        self.top_bar.setMinimumSize(QSize(0, 50))
        self.top_bar.setStyleSheet(u"background-color: rgb(43, 62, 99);\n"
"color: white")
        self.horizontalLayout_2 = QHBoxLayout(self.top_bar)
        self.horizontalLayout_2.setSpacing(10)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(20, 0, 20, 0)
        self.widget_info_2 = QWidget(self.top_bar)
        self.widget_info_2.setObjectName(u"widget_info_2")
        self.widget_info_2.setMinimumSize(QSize(200, 0))
        self.widget_info_2.setMaximumSize(QSize(200, 30))
        self.verticalLayout_5 = QVBoxLayout(self.widget_info_2)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.lb_titulo = QLabel(self.widget_info_2)
        self.lb_titulo.setObjectName(u"lb_titulo")
        self.lb_titulo.setMaximumSize(QSize(16777215, 20))
        font5 = QFont()
        font5.setFamilies([u"Segoe UI"])
        font5.setPointSize(17)
        font5.setBold(False)
        font5.setItalic(False)
        font5.setUnderline(False)
        font5.setStrikeOut(False)
        font5.setKerning(True)
        self.lb_titulo.setFont(font5)
        self.lb_titulo.setStyleSheet(u"QLabel {\n"
"	color: white\n"
"}")

        self.verticalLayout_5.addWidget(self.lb_titulo)


        self.horizontalLayout_2.addWidget(self.widget_info_2)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.lb_titulo_3 = QLabel(self.top_bar)
        self.lb_titulo_3.setObjectName(u"lb_titulo_3")
        self.lb_titulo_3.setMinimumSize(QSize(75, 0))
        self.lb_titulo_3.setMaximumSize(QSize(80, 20))
        font6 = QFont()
        font6.setFamilies([u"Segoe UI"])
        font6.setPointSize(12)
        font6.setBold(True)
        self.lb_titulo_3.setFont(font6)
        self.lb_titulo_3.setStyleSheet(u"QLabel {\n"
"	color: rgb(0, 193, 255)\n"
"}")

        self.horizontalLayout_2.addWidget(self.lb_titulo_3)

        self.lb_titulo_2 = QLabel(self.top_bar)
        self.lb_titulo_2.setObjectName(u"lb_titulo_2")
        self.lb_titulo_2.setMinimumSize(QSize(300, 0))
        self.lb_titulo_2.setMaximumSize(QSize(16777215, 20))
        font7 = QFont()
        font7.setFamilies([u"Segoe UI"])
        font7.setPointSize(10)
        font7.setBold(True)
        font7.setItalic(True)
        self.lb_titulo_2.setFont(font7)
        self.lb_titulo_2.setStyleSheet(u"QLabel {\n"
"	color: white\n"
"}")
        self.lb_titulo_2.setTextInteractionFlags(Qt.LinksAccessibleByMouse|Qt.TextSelectableByMouse)

        self.horizontalLayout_2.addWidget(self.lb_titulo_2)

        self.widget_info = QWidget(self.top_bar)
        self.widget_info.setObjectName(u"widget_info")
        self.widget_info.setMinimumSize(QSize(100, 0))
        self.widget_info.setMaximumSize(QSize(16777215, 30))
        self.verticalLayout_4 = QVBoxLayout(self.widget_info)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.lb_tipo1 = QLabel(self.widget_info)
        self.lb_tipo1.setObjectName(u"lb_tipo1")
        self.lb_tipo1.setMaximumSize(QSize(16777215, 20))
        font8 = QFont()
        font8.setFamilies([u"Segoe UI"])
        font8.setBold(False)
        self.lb_tipo1.setFont(font8)
        self.lb_tipo1.setStyleSheet(u"QLabel {\n"
"	color: white\n"
"}")

        self.verticalLayout_4.addWidget(self.lb_tipo1)

        self.lb_tipo2 = QLabel(self.widget_info)
        self.lb_tipo2.setObjectName(u"lb_tipo2")
        self.lb_tipo2.setMaximumSize(QSize(16777215, 20))
        font9 = QFont()
        font9.setFamilies([u"Segoe UI"])
        font9.setPointSize(8)
        self.lb_tipo2.setFont(font9)
        self.lb_tipo2.setStyleSheet(u"QLabel {\n"
"	color: white\n"
"}")

        self.verticalLayout_4.addWidget(self.lb_tipo2)


        self.horizontalLayout_2.addWidget(self.widget_info)

        self.btn_user = QPushButton(self.top_bar)
        self.btn_user.setObjectName(u"btn_user")
        self.btn_user.setMinimumSize(QSize(40, 40))
        self.btn_user.setMaximumSize(QSize(40, 40))
        self.btn_user.setFont(font3)
        self.btn_user.setStyleSheet(u"QPushButton {\n"
"	background: rgb(165, 29, 45);\n"
"	border-radius: 10px;\n"
"}\n"
"")

        self.horizontalLayout_2.addWidget(self.btn_user)


        self.verticalLayout.addWidget(self.top_bar)

        self.lb_msg = QLabel(self.content)
        self.lb_msg.setObjectName(u"lb_msg")
        self.lb_msg.setMaximumSize(QSize(16777215, 0))
        self.lb_msg.setStyleSheet(u"QLabel {\n"
"	color: white;\n"
"	background-color: rgb(87, 227, 137);\n"
"border-radius: 5px;\n"
"margin: 0px 40px;\n"
"padding: 10px;\n"
"}")

        self.verticalLayout.addWidget(self.lb_msg)

        self.stackedWidget = QStackedWidget(self.content)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.stackedWidget.addWidget(self.page)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.stackedWidget.addWidget(self.page_2)

        self.verticalLayout.addWidget(self.stackedWidget)


        self.horizontalLayout.addWidget(self.content)


        self.retranslateUi(Main)

        QMetaObject.connectSlotsByName(Main)
    # setupUi

    def retranslateUi(self, Main):
        Main.setWindowTitle(QCoreApplication.translate("Main", u"Form", None))
        self.toggle.setText("")
        self.btn_chamados.setText(QCoreApplication.translate("Main", u"Chamados", None))
        self.btn_abrirChamado.setText(QCoreApplication.translate("Main", u"Abrir Chamado", None))
        self.lb_titulo_7.setText(QCoreApplication.translate("Main", u"<a style='color: white; text-decoration: none' href='https://techsize.com.br/downloads/'>Downloads</a>", None))
        self.lb_titulo_5.setText(QCoreApplication.translate("Main", u"Vers\u00e3o", None))
        self.lb_titulo_4.setText(QCoreApplication.translate("Main", u"1.0.1", None))
        self.lb_titulo_6.setText("")
        self.lb_titulo.setText("")
        self.lb_titulo_3.setText(QCoreApplication.translate("Main", u"Hostname:", None))
        self.lb_titulo_2.setText(QCoreApplication.translate("Main", u"desktop-123", None))
        self.lb_tipo1.setText(QCoreApplication.translate("Main", u"Admin", None))
        self.lb_tipo2.setText(QCoreApplication.translate("Main", u"Entidade Raiz", None))
        self.btn_user.setText(QCoreApplication.translate("Main", u"GF", None))
        self.lb_msg.setText("")
    # retranslateUi

