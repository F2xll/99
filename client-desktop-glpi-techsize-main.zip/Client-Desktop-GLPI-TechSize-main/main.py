from PySide6.QtWidgets import QApplication, QMenu, QSystemTrayIcon
from PySide6.QtGui import QIcon, QAction
from views.HomeView import HomeView
from models.HomeModel import HomeModel
from controllers.HomeController import HomeController
import sys


if __name__ == "__main__":
    root = QApplication(sys.argv)
    app = HomeController(HomeView(), HomeModel())

    root.setQuitOnLastWindowClosed(False)
    icon = QIcon("interface/images/icon.ico")
    tray = QSystemTrayIcon()
    tray.setIcon(icon)
    tray.setVisible(True)
    tray.activated.connect(app.show)
    root.exec_()
