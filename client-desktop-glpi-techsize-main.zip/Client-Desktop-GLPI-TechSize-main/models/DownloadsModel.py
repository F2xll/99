from base_class.Model import Model


class DownloadsModel(Model):

    def __init__(self, api):
        super().__init__()
