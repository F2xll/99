import sys
from cx_Freeze import setup, Executable

# Dependencies are automatically detected, but it might need fine tuning.
# "packages": ["os"] is used as example only
build_exe_options = {
    "packages": ["os", "sys", "ctypes"],
    "excludes": ["tkinter"],
    "include_files": [
        "icon.ico", "tokens.json", "README.txt", "interface/images/", "GLPI-Agent-1.5-giteab5c585-x64.msi"],
    "include_msvcr" : True,
}

# base="Win32GUI" should be used only for Windows GUI app
base = None
if sys.platform == "win32":
    base = "Win32GUI"

setup(
    name="Client Help Desk",
    version="1.0.1",
    fullname = "Client Help Desk 1.0.1",
    description="Client Help Desk",
    options={"build_exe": build_exe_options},
    executables=[Executable(
        "main.py",
        base=base,
        target_name="Client Help Desk",
        icon="icon.ico",
        copyright="Copyright © 2022 Techsize. Todos os direitos Reservados."
    )],
)
