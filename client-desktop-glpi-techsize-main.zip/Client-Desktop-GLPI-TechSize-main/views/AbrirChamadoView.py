from base_class.View import View
from interface.abrir_chamado import Ui_Form
import socket
from PySide6.QtCore import Qt
from views.AnexoView import AnexoView
from PySide6.QtWidgets import QSpacerItem, QSizePolicy


class AbrirChamadoView(View, Ui_Form):

    def __init__(self, parent=None):
        super().__init__(parent)
        super().setupUi(self)

        self._items = []
        self._space = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

    def preencher_categoria(self, dados: [dict]):
        self.cb_categoria.clear()
        self.cb_categoria.addItem('-----')
        for item in dados:
            for i in item.values():
                self.cb_categoria.addItem(i)

    def preencher_cb(self, cb, dados: dict):
        cb.clear()
        for item in dados.values():
            cb.addItem(item)

    @property
    def get_titulo(self):
        return self.lb_titulo.text() + "/" + socket.gethostname()

    @property
    def get_texto(self):
        return self.txt_descricao.toPlainText()

    @property
    def get_categoria(self):
        return self.cb_categoria.currentText()

    @property
    def get_urgencia(self):
        return self.cb_urgencia.currentText()

    def limpar(self, msg, urgencia, categoria):
        self.preencher_cb(self.cb_urgencia, urgencia)
        self.preencher_categoria(categoria)
        self.cb_urgencia.setCurrentIndex(2)
        self.txt_descricao.setPlainText("")
        self.lb_titulo.setText('')
        msg.setMaximumHeight(0)
        self.limpar_anexo()

    @property
    def status(self):
        return True if self.get_titulo != '' and self.get_texto != '' and self.get_categoria != '-----' else False

    @property
    def get_dados(self):
        return {
            "name": self.get_titulo,
            "content": self.get_texto,
            "urgency": self.get_urgencia,
            "category": self.get_categoria
        }

    def adiciona_item(self, dados, anexos):
        item = AnexoView(dados, anexos)
        self.verticalLayout_5.addWidget(item)
        self._items.append(item)

    def preencher_anexos(self, dados):
        self.limpar_anexo()
        if len(dados) != 0:
            for i in dados:
                self.adiciona_item(i, dados)

            self.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.scrollArea.setWidgetResizable(True)
            self.verticalLayout_5.addSpacerItem(self._space)

        return self._items

    def limpar_anexo(self):
            for i in self._items:
                i.deleteLater()
                i = None
            self._items = []
            self.verticalLayout_5.removeItem(self._space)

