from base_class.View import View
from interface.tokens import Ui_Form
from PySide6.QtGui import QIcon
from PySide6.QtCore import QSize


class TokensView(View, Ui_Form):

    def __init__(self, tokens: dict, parent=None):
        super().__init__(parent)
        super().setupUi(self)
        self.setWindowTitle("Client Help Desk")
        self.setWindowIcon(QIcon('.//interface/images/icone_sistema.png'))

        self.logo.setIcon(QIcon('.//interface/images/Logo_Techsize.png'))
        self.logo.setIconSize(QSize(240, 245))

        self._tokens = tokens
        self.definir_campos()

    def definir_campos(self) -> None:
        self.input_tokenUser.setText(self._tokens['user_Token'])
        self.input_tokenAPI.setText(self._tokens['app_Token'])

    def salvar(self) -> dict:
        dados = {
            "user_Token": self.input_tokenUser.text(),
            "app_Token": self.input_tokenAPI.text()
        }

        if dados['user_Token'] == '' or dados['app_Token'] == '':
            self.msg_error('Preencha ambos os campos!', True)
        else:
            self.msg_error('', False)
        return dados

    def msg_error(self, msg: str, status: bool):
        try:
            self.lb_error.setText(msg)
            if status == True:
                self.lb_error.setMaximumHeight(30)
            else:
                self.lb_error.setMaximumHeight(0)
        except:
            pass

